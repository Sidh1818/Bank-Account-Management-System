import java.util.InputMismatchException;
import java.util.Scanner;

// User-defined Exception: InvalidAmountException
class InvalidAmountException extends Exception {
    public InvalidAmountException(String message) {
        super(message);
    }
}

// User-defined Exception: InsufficientFundsException
class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

// BankAccount Class
class BankAccount {
    private String accountHolder;
    private double balance;

    public BankAccount(String accountHolder) {
        this.accountHolder = accountHolder;
        this.balance = 0.0;
    }

    public void deposit(double amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive.");
        }
        balance += amount;
        System.out.println("Deposit successful. New balance: $" + balance);
    }

    public void withdraw(double amount) throws InvalidAmountException, InsufficientFundsException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be positive.");
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient funds. Available balance: $" + balance);
        }
        balance -= amount;
        System.out.println("Withdrawal successful. New balance: $" + balance);
    }

    public void viewBalance() {
        System.out.println("Current balance: $" + balance);
    }

    public String getAccountHolder() {
        return accountHolder;
    }
}

// Main Application
public class BankSytem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount account = null;

        try {
            System.out.print("Enter your name to create an account: ");
            String name = scanner.nextLine();
            account = new BankAccount(name);
            System.out.println("Account created for " + account.getAccountHolder());

            boolean exit = false;

            while (!exit) {
                System.out.println("\n1. Deposit");
                System.out.println("2. Withdraw");
                System.out.println("3. View Balance");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");

                try {
                    int choice = scanner.nextInt();

                    switch (choice) {
                        case 1:
                            System.out.print("Enter amount to deposit: ");
                            double depositAmount = scanner.nextDouble();
                            account.deposit(depositAmount);
                            break;

                        case 2:
                            System.out.print("Enter amount to withdraw: ");
                            double withdrawAmount = scanner.nextDouble();
                            account.withdraw(withdrawAmount);
                            break;

                        case 3:
                            account.viewBalance();
                            break;

                        case 4:
                            exit = true;
                            System.out.println("Thank you for using our bank system!");
                            break;

                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }

                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter numeric values.");
                    scanner.nextLine(); // clear invalid input
                } catch (InvalidAmountException | InsufficientFundsException e) {
                    System.out.println("Error: " + e.getMessage());
                } catch (Exception e) {
                    System.out.println("Unexpected error occurred: " + e.getMessage());
                }
            }

        } finally {
            // Always close scanner
            if (scanner != null) {
                scanner.close();
                System.out.println("Scanner closed.");
            }
        }
    }
}
