import javax.swing.*;

class BankAccount {
    private String accountHolder;
    private double balance;

    public BankAccount(String accountHolder) {
        this.accountHolder = accountHolder;
        this.balance = 0.0;
    }

    public void deposit(double amount) throws Exception {
        if (amount <= 0) {
            throw new Exception("Deposit amount must be positive.");
        }
        balance += amount;
    }

    public void withdraw(double amount) throws Exception {
        if (amount <= 0) {
            throw new Exception("Withdrawal amount must be positive.");
        }
        if (amount > balance) {
            throw new Exception("Insufficient funds. Available balance: $" + balance);
        }
        balance -= amount;
    }

    public double getBalance() {
        return balance;
    }

    public String getAccountHolder() {
        return accountHolder;
    }
}

public class BankGUIProject2 {
    private static BankAccount account; 

    public static void main(String[] args) {
        String name = JOptionPane.showInputDialog("Enter your name to create an account:");
        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Name cannot be empty. Exiting...");
            return;
        }

        account = new BankAccount(name);

        JFrame frame = new JFrame("Bank Account - " + account.getAccountHolder());
        JButton depositBtn = new JButton("Deposit");
        JButton withdrawBtn = new JButton("Withdraw");
        JButton viewBalanceBtn = new JButton("View Balance");

        depositBtn.setBounds(50, 100, 120, 30);
        withdrawBtn.setBounds(180, 100, 120, 30);
        viewBalanceBtn.setBounds(310, 100, 140, 30);

        frame.add(depositBtn);
        frame.add(withdrawBtn);
        frame.add(viewBalanceBtn);

        depositBtn.addActionListener(e -> {
            String input = JOptionPane.showInputDialog("Enter amount to deposit:");
            try {
                double amount = Double.parseDouble(input);
                account.deposit(amount);
                JOptionPane.showMessageDialog(null, "Deposit successful!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        });

        withdrawBtn.addActionListener(e -> {
            String input = JOptionPane.showInputDialog("Enter amount to withdraw:");
            try {
                double amount = Double.parseDouble(input);
                account.withdraw(amount);
                JOptionPane.showMessageDialog(null, "Withdrawal successful!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        });

        viewBalanceBtn.addActionListener(e -> {
            String message = "Account Holder: " + account.getAccountHolder()
                    + "\nCurrent Balance: $" + account.getBalance();
            JOptionPane.showMessageDialog(null, message);
        });

        frame.setSize(520, 250);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
